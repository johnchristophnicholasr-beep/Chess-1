package com.example.chess;
import android.app.*; import android.os.*; import android.graphics.*; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
  public void onCreate(Bundle b){super.onCreate(b); setContentView(new Board(this));}
  static class Board extends View {
    Paint p=new Paint(1); int sel=-1; String[] pieces={"♜","♞","♝","♛","♚","♝","♞","♜","♟","♟","♟","♟","♟","♟","♟","♟","","","","","","","","","","","","","","","","","♙","♙","♙","♙","♙","♙","♙","♙","♖","♘","♗","♕","♔","♗","♘","♖"};
    Board(MainActivity c){super(c); p.setTypeface(Typeface.DEFAULT); setBackgroundColor(Color.WHITE);}
    protected void onDraw(Canvas c){float s=getWidth()/8f; for(int r=0;r<8;r++)for(int q=0;q<8;q++){p.setColor(((r+q)%2==0)?Color.rgb(240,217,181):Color.rgb(181,136,99));c.drawRect(q*s,r*s,(q+1)*s,(r+1)*s,p);String x=pieces[r*8+q];if(!x.isEmpty()){p.setTextSize(s*.72f);p.setColor(Color.BLACK);p.setTextAlign(Paint.Align.CENTER);c.drawText(x,(q+.5f)*s,(r+.72f)*s,p);}}}
    public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==1){int q=(int)(e.getX()/(getWidth()/8f)),r=(int)(e.getY()/(getWidth()/8f)); if(sel<0)sel=r*8+q;else{String t=pieces[sel];pieces[sel]="";pieces[r*8+q]=t;sel=-1;invalidate();}return true;}return true;}
  }
}
