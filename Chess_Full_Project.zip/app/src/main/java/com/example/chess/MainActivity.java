package com.example.chess;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    int level = 1;
    final String[] modes = {"Classic 1v1","2v2","3v3","4v4","5v5","Practice"};
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showLoading();
    }
    void showLoading() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.rgb(18,18,18));
        TextView t = text("♟  CHESS", 36, Color.WHITE);
        t.setGravity(Gravity.CENTER);
        f.addView(t, new FrameLayout.LayoutParams(-1,-1));
        setContentView(f);
        new Handler().postDelayed(this::home, 1200);
    }
    TextView text(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(20,14,20,14); return t;
    }
    Button btn(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false);
        return b;
    }
    void home() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,20); root.setBackgroundColor(Color.rgb(245,245,245));
        TextView title=text("♟ CHESS",30,Color.DKGRAY); root.addView(title);
        TextView lv=text("Level "+level+" / 100   •   No Ads",18,Color.DKGRAY); root.addView(lv);
        Button play=btn("Play Chess"); play.setOnClickListener(v->game("Classic 1v1")); root.addView(play);
        Button modesBtn=btn("Custom Modes"); modesBtn.setOnClickListener(v->modeMenu()); root.addView(modesBtn);
        Button practice=btn("Beginner Tutorial • Levels 1–10"); practice.setOnClickListener(v->tutorial()); root.addView(practice);
        Button stats=btn("Profile • Achievements • Statistics"); stats.setOnClickListener(v->stats()); root.addView(stats);
        setContentView(root);
    }
    void modeMenu() {
        root.removeAllViews(); root.addView(text("CUSTOM MODES",28,Color.DKGRAY));
        for(String m:modes){ Button b=btn(m); b.setOnClickListener(v->game(((Button)v).getText().toString())); root.addView(b); }
        Button back=btn("← Back"); back.setOnClickListener(v->home()); root.addView(back);
    }
    void tutorial() {
        root.removeAllViews(); root.addView(text("BEGINNER TUTORIAL",28,Color.DKGRAY));
        String[] lessons={"Board & pieces","Pawns","Rooks","Bishops","Knights","Queen","King","Capturing","Check & checkmate","Play a full beginner game"};
        for(int i=0;i<10;i++){
            final int n=i+1; Button b=btn("Level "+n+" • "+lessons[i]);
            b.setOnClickListener(v->{Toast.makeText(this,"Practice lesson "+n+" selected",Toast.LENGTH_SHORT).show(); game("Practice Level "+n);});
            root.addView(b);
        }
        Button back=btn("← Back"); back.setOnClickListener(v->home()); root.addView(back);
    }
    void stats() {
        root.removeAllViews(); root.addView(text("PROFILE & STATS",28,Color.DKGRAY));
        root.addView(text("Level: "+level+"/100\nAchievements: 0/20\nRating: 1000\nAccuracy: --\nOpening statistics: available after games\nRating graph: available after games",17,Color.DKGRAY));
        Button back=btn("← Back"); back.setOnClickListener(v->home()); root.addView(back);
    }
    void game(String mode) {
        setContentView(new Board(this, mode));
    }
    class Board extends View {
        Paint p=new Paint(1); String mode; String[] pieces={
            "♜","♞","♝","♛","♚","♝","♞","♜","♟","♟","♟","♟","♟","♟","♟","♟",
            "","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",
            "♙","♙","♙","♙","♙","♙","♙","♙","♖","♘","♗","♕","♔","♗","♘","♖"};
        int selected=-1;
        Board(Activity a,String m){super(a);mode=m;}
        protected void onDraw(Canvas c){
            float s=getWidth()/8f;
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(s*.70f);
            for(int r=0;r<8;r++)for(int x=0;x<8;x++){
                p.setColor((r+x)%2==0?Color.rgb(240,217,181):Color.rgb(181,136,99)); c.drawRect(x*s,r*s,(x+1)*s,(r+1)*s,p);
                int i=r*8+x;
                if(i==selected){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);p.setColor(Color.YELLOW);c.drawRect(x*s+3,r*s+3,(x+1)*s-3,(r+1)*s-3,p);p.setStyle(Paint.Style.FILL);}
                if(!pieces[i].equals("")){p.setColor(Color.BLACK);c.drawText(pieces[i],(x+.5f)*s,(r+.72f)*s,p);}
            }
        }
        public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=1)return true; float s=getWidth()/8f; int x=(int)(e.getX()/s),r=(int)(e.getY()/s),q=r*8+x;
            if(selected<0){if(!pieces[q].equals(""))selected=q;}else{pieces[q]=pieces[selected];pieces[selected]="";selected=-1;} invalidate(); return true;
        }
    }
}
