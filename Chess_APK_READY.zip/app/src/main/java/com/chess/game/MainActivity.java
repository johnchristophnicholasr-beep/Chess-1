package com.chess.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new ChessView(this));
    }

    static class ChessView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        String[] board = {
            "♜♞♝♛♚♝♞♜","♟♟♟♟♟♟♟♟","        ","        ",
            "        ","        ","♙♙♙♙♙♙♙♙","♖♘♗♕♔♗♘♖"
        };
        int selected = -1;

        ChessView(Context c) { super(c); p.setTypeface(Typeface.DEFAULT); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.rgb(7,17,26));
            float top = 150, size = Math.min(getWidth(), getHeight()-250) / 8f;

            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            p.setTextSize(42);
            p.setColor(Color.WHITE);
            c.drawText("♟  CHESS", getWidth()/2f, 65, p);
            p.setTextSize(18);
            p.setColor(Color.LTGRAY);
            c.drawText("Beginner • Level 1", getWidth()/2f, 105, p);

            for (int r=0;r<8;r++) for (int col=0;col<8;col++) {
                boolean light=(r+col)%2==0;
                p.setColor(light ? Color.rgb(225,225,210) : Color.rgb(55,95,110));
                c.drawRect(col*size, top+r*size, (col+1)*size, top+(r+1)*size, p);
                char ch=board[r].charAt(col);
                if(ch!=' ') {
                    p.setColor((ch=='♟'||ch=='♜'||ch=='♞'||ch=='♝'||ch=='♛'||ch=='♚') ? Color.rgb(20,25,30) : Color.WHITE);
                    p.setTextSize(size*.65f);
                    c.drawText(String.valueOf(ch), col*size+size/2, top+r*size+size*.72f, p);
                }
            }

            p.setColor(Color.rgb(12,35,48));
            c.drawRoundRect(24, top+8*size+25, getWidth()-24, top+8*size+90, 22,22,p);
            p.setColor(Color.WHITE);
            p.setTextSize(18);
            c.drawText("Easy AI     Normal AI     Hard AI", getWidth()/2f, top+8*size+64, p);

            p.setColor(Color.rgb(0,184,255));
            c.drawCircle(55, getHeight()-55, 30, p);
            p.setColor(Color.WHITE);
            p.setTextSize(25);
            c.drawText("🎙", 55, getHeight()-47, p);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_UP) invalidate();
            return true;
        }
    }
}
